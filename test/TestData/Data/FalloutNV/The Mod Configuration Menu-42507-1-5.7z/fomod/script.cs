using System;
using fomm.Scripting;

using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Forms;


class Script : FalloutNewVegasBaseScript
{

	const string title = "The Mod Configuration Menu";

	static ASCIIEncoding encoding;

	public static bool install;
	public static bool installFail;
	public static Form InstallForm;
	public static PictureBox MCMIcon;
	public static Button InstallButton;
	public static Button CancelButton;
	public static Label NVSELabel;
	public static PictureBox NVSESymbol;
	public static Label XMLLabel;

	public static bool OnActivate()
	{

		encoding = new ASCIIEncoding();

		CreateInstallForm();
		InstallForm.ShowDialog();
		if (install)
			InstallMCM();
		return install;
	}
	static bool InstallMCM()
	{
		// Install base files
		string[] excludes = new string[] {
			"includes_StartMenu.xml",
			"start_menu.xml"
		};

		InstallBaseFiles(excludes);
		SetPluginActivation("The Mod Configuration Menu.esp", true);

		UpdateUIFile("menus/options/start_menu.xml", "includes_StartMenu.xml", "includes_StartMenu.xml", "MCM.xml");
		UpdateUIFile("menus/prefabs/includes_StartMenu.xml", @"MCM\MCM.xml", "MCM.xml", "MCM.xml");

		return true;
	}

	public static void InstallBaseFiles(string[] excludes)
	{
		string[] files = GetFomodFileList();

		foreach (string file in files)
		{

			if (file.StartsWith("fomod", true, null))
				continue;

			bool found = false;
			foreach (string exclude in excludes)
			{
				if (file.EndsWith(exclude, true, null) || file.StartsWith(exclude, true, null))
				{
					found = true;
					continue;
				}
			}
			if (found)
				continue;

			InstallFileFromFomod(file);
		}
	}

	public static void UpdateUIFile(string xmlPath, string includePath, string matchString, string matchString2)
	{
		if (!DataFileExists(xmlPath))
		{
			InstallFileFromFomod(xmlPath);
		}
		else
		{
			byte[] data = GetExistingDataFile(xmlPath);

			string tmp = encoding.GetString(data);
			string includeStr;

			if (!Regex.IsMatch(tmp, matchString) && !Regex.IsMatch(tmp, matchString2))
			{
				if (includePath == "includes_StartMenu.xml")
				{

					includeStr = "\t<include src=\"" + includePath + "\" />\r\n";

					tmp = Regex.Replace(tmp,
						"<menu name=\"(\\w+)\">(.*)</menu>\\s*$",
						"<menu name=\"$1\">$2" + includeStr + "</menu>",
						RegexOptions.Singleline);
				}
				else
				{
					tmp += "\r\n"
						+ "<!-- BEGIN Added by " + title + " -->\r\n"
						+ "<include src=\"" + includePath + "\" />\r\n"
						+ "<!-- END Added by " + title + " -->\r\n";
				}

				data = encoding.GetBytes(tmp);
				if (!installFail)
				{
					try
					{
						GenerateDataFile(xmlPath, data);
					}
					catch
					{
						installFail = true;

						InstallButton.Visible = false;
						CancelButton.Location = new Point(100, 340);
						CancelButton.Text = "Close";
						NVSESymbol.Image = GetImageFromFomod("fomod/false.png");
						NVSELabel.Text = "Menu install failed. Cannot access menu files.\r\nTry using Fallout Mod Manager or changing firewall/UAC settings.";
						XMLLabel.Visible = false;

						InstallForm.ShowDialog();
					}
				}
			}
		}
	}

	static bool InstallFileFromFomod(string source, string target)
	{
		byte[] data = GetFileFromFomod(source);
		if (data == null)
			return false;

		return GenerateDataFile(target, data);
	}

	public static void CreateInstallForm()
	{
		InstallForm = CreateCustomForm();
		InstallForm.BackColor = Color.FromArgb(64, 64, 64);
		InstallForm.FormBorderStyle = FormBorderStyle.FixedToolWindow;
		InstallForm.StartPosition = FormStartPosition.CenterScreen;
		InstallForm.Size = new Size(300, 400);
		InstallForm.Text = title;

		MCMIcon = new PictureBox();
		MCMIcon.Image = GetImageFromFomod("fomod/MCM.png");
		MCMIcon.Location = new Point(50, 25);
		MCMIcon.Size = new Size(200, 200);
		MCMIcon.SizeMode = PictureBoxSizeMode.Zoom;
		InstallForm.Controls.Add(MCMIcon);

		InstallButton = new Button();
		InstallButton.Location = new Point(40, 340);
		InstallButton.Size = new Size(100, 23);
		InstallButton.Text = "Install";
		InstallButton.UseVisualStyleBackColor = true;
		InstallForm.Controls.Add(InstallButton);

		CancelButton = new Button();
		CancelButton.Location = new Point(160, 340);
		CancelButton.Size = new Size(100, 23);
		CancelButton.Text = "Cancel";
        CancelButton.UseVisualStyleBackColor = true;
		InstallForm.Controls.Add(CancelButton);

		NVSELabel = new Label();
		NVSELabel.AutoSize = true;
		NVSELabel.ForeColor = Color.FromArgb(224, 224, 224);
		NVSELabel.Location = new Point(25, 271);
		NVSELabel.MaximumSize = new Size(250, 0);
		InstallForm.Controls.Add(NVSELabel);

		NVSESymbol = new PictureBox();
		NVSESymbol.Location = new Point(8, 269);
		NVSESymbol.Size = new Size(16, 16);
		InstallForm.Controls.Add(NVSESymbol);

		bool GetNVSE = ScriptExtenderPresent();
		Version CurrentNVSE = GetNvseVersion();
		Version RequiredNVSE = new Version(0, 2, 0, 3);
		if (CurrentNVSE >= RequiredNVSE)
		{
			NVSELabel.Text = "NVSE " + CurrentNVSE + " detected.";
			NVSESymbol.Image = GetImageFromFomod("fomod/true.png");
		}
		else
		{
			NVSESymbol.Image = GetImageFromFomod("fomod/false.png");
			if (GetNVSE == false)
			{
				NVSELabel.Text = "NVSE not detected.";
			}
			else
			{
				NVSELabel.Text = "NVSE " + CurrentNVSE + " outdated.";
			}
		}

		XMLLabel = new Label();
		XMLLabel.AutoSize = true;
		XMLLabel.ForeColor = Color.FromArgb(224, 224, 224);
		XMLLabel.Location = new Point(25, 289);
		XMLLabel.MaximumSize = new Size(250, 0);
		InstallForm.Controls.Add(XMLLabel);
		if (DataFileExists("menus/options/start_menu.xml"))
		{
			XMLLabel.Text = "Menu file detected. Allow overwrite to insert data. (Existing data will be preserved.)";
		}
		else
		{
			XMLLabel.Text = "Ready to install.";
		}

		AttachHandlers();
	}

	public static Image GetImageFromFomod(string filename)
	{
		byte[] data = GetFileFromFomod(filename);
		MemoryStream s = new MemoryStream(data);
		Image img = Image.FromStream(s);
		s.Close();
		return img;
	}

	public static void AttachHandlers()
	{
		InstallButton.Click += delegate(object sender, EventArgs args)
		{
			install = true;
			InstallForm.Close();
		};
		CancelButton.Click += delegate(object sender, EventArgs args)
		{
			if (InstallButton.Enabled || installFail)
				install = false;
			InstallForm.Close();
		};
	}
}