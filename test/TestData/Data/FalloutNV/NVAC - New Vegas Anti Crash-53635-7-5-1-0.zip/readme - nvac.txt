NVAC - New Vegas Anti Crash

Since it's an NVSE plugin, nvac.dll goes in your Data\NVSE\Plugins folder.

Also works (to a lesser degree) with Fallout 3, Oblivion and Skyrim.

---

Fixes Windows 10 Anniversary Update (Win10AU) video driver issues for:

Fallout New Vegas
Fallout New Vegas No Gore (German)
Fallout 3
Fallout 3 No Gore (German)
Oblivion
GECK (New Vegas)
GECK (Fallout 3)
Construction Set (Oblivion)

---

Program-specific exception list:

Fallout New Vegas

00005440 / 00405440
00040DAA / 00440DAA (preliminary)
0006158A / 0046158A (missingmstr)
0007CF1E / 0047CF1E (leveledlist)
000B068D / 004B068D (preliminary)
0011E2EA / 0051E2EA
0014546F / 0054546F (preliminary)
001595B1 / 005595B1 (preliminary)
0017C876 / 0057C876 (preliminary)
001A8EE0 / 005A8EE0 (preliminary)
001E0DF4 / 005E0DF4
001E0F16 / 005E0F16 (preliminary)
001E11DC / 005E11DC
0024DAD6 / 0064DAD6 (preliminary)
002A7F22 / 006A7F22 (preliminary)
001A870C / 006A870C (preliminary)
002ADB69 / 006ADB69 (preliminary)
002B3542 / 006B3542 (preliminary)
002B43FC / 006B43FC (preliminary)
002B9102 / 006B9102 (preliminary)
002B96CC / 006B96CC (preliminary)
002BF1DA / 006BF1DA (preliminary)
002BF48E / 006BF48E (preliminary)
002F3F52 / 006F3F52 (preliminary)
002F47FC / 006F47FC (preliminary)
002FCF03 / 006FCF03 (disabledlod)
00404432 / 00804432 (preliminary)
0065E378 / 00A5E378 (preliminary)
00661693 / 00A61693
00661A74 / 00A61A74
006A55A6 / 00AA55A6 (outofmemory)
006A9A41 / 00AA9A41 (outofmemory)
006AA60A / 00AAA60A (outofmemory)
006AA62E / 00AAA62E (outofmemory)
00757AA9 / 00B57AA9 (vidfilename)
00763EFF / 00B63EFF (preliminary)
0089E64E / 00C9E64E (preliminary)
0091F29C / 00D1F29C (outofmemory)
00A8C00D / 00E8C00D (preliminary)
00AD2C9E / 00ED2C9E (outofmemory)

GECK (New Vegas)

00536733 / 00936733
